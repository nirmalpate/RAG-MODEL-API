"""
rag.py  =  the AI layer.
It knows NOTHING about HTTP, FastAPI or Slack. It only knows how to:
load PDFs -> chunk -> index -> retrieve -> rerank -> generate an answer.
"""

import os  # os: work with file paths and environment variables

# ---- LangChain / HuggingFace imports (same as your notebook) ----
from langchain_community.document_loaders import PyPDFLoader  # reads a PDF, one Document per page
from langchain_text_splitters import RecursiveCharacterTextSplitter  # cuts text into chunks
from langchain_huggingface import HuggingFaceEmbeddings, HuggingFacePipeline, ChatHuggingFace  # embeddings + local LLM wrappers
from langchain_chroma import Chroma  # vector database
from langchain_community.retrievers import BM25Retriever  # keyword search
from langchain_community.cross_encoders import HuggingFaceCrossEncoder  # model that scores (question, chunk) pairs
from langchain_classic.retrievers import EnsembleRetriever, ContextualCompressionRetriever  # combine retrievers / post-process results
from langchain_classic.retrievers.document_compressors import CrossEncoderReranker  # reranking step
from langchain_classic.chains import create_retrieval_chain  # retrieve -> answer pipeline
from langchain_classic.chains.combine_documents import create_stuff_documents_chain  # puts chunks into the prompt and calls the LLM
from langchain_core.prompts import ChatPromptTemplate  # builds the system + human prompt
from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline  # load and run a local LLM

# ---- Settings. Environment variables let you change them without editing code ----
EMBEDDING_MODEL = os.environ.get("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")  # turns text into vectors
RERANKER_MODEL = os.environ.get("RERANKER_MODEL", "BAAI/bge-reranker-base")  # picks the best chunks
LOCAL_LLM_NAME = os.environ.get("LOCAL_LLM_NAME", "Qwen/Qwen2.5-1.5B-Instruct")  # used if no Groq key is set
GROQ_MODEL = os.environ.get("GROQ_MODEL", "llama-3.1-8b-instant")  # used if GROQ_API_KEY is set


def load_chunks(pdf_dir, chunk_size=500, chunk_overlap=50):
    """Read every PDF in pdf_dir and return a list of small text chunks."""
    pdf_files = [f for f in os.listdir(pdf_dir) if f.lower().endswith(".pdf")]  # keep only .pdf files (case-insensitive)
    if not pdf_files:  # empty list means nothing to index
        return []  # caller decides what to do

    documents = []  # will hold one Document per PDF page
    for name in pdf_files:  # loop over each PDF file name
        pages = PyPDFLoader(os.path.join(pdf_dir, name)).load()  # build full path, read all pages
        documents.extend(pages)  # add this file's pages to the big list

    splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)  # 500 chars, 50 overlap
    return splitter.split_documents(documents)  # split pages into chunks (keeps file + page metadata)


def build_retriever(chunks):
    """Hybrid search (keywords + meaning) followed by a reranker."""
    embeddings = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL)  # load the embedding model
    vectorstore = Chroma.from_documents(documents=chunks, embedding=embeddings)  # embed chunks and store them

    bm25 = BM25Retriever.from_documents(chunks)  # keyword index over the same chunks
    bm25.k = 5  # return top 5 keyword matches

    vector = vectorstore.as_retriever(search_kwargs={"k": 5})  # top 5 meaning matches

    hybrid = EnsembleRetriever(retrievers=[bm25, vector], weights=[0.4, 0.6])  # merge both lists, 40% keyword / 60% meaning

    reranker = CrossEncoderReranker(  # re-scores each chunk against the question
        model=HuggingFaceCrossEncoder(model_name=RERANKER_MODEL),  # the scoring model
        top_n=3,  # keep only the best 3
    )
    return ContextualCompressionRetriever(  # run hybrid search, then the reranker
        base_compressor=reranker,
        base_retriever=hybrid,
    )


def build_llm():
    """Return a chat LLM. Uses Groq (hosted, fast) if GROQ_API_KEY exists, else a local model."""
    groq_key = os.environ.get("GROQ_API_KEY")  # None if not set
    if groq_key:  # hosted option: good for servers with no GPU
        from langchain_groq import ChatGroq  # imported here so it is only needed when used
        return ChatGroq(model=GROQ_MODEL, api_key=groq_key, temperature=0)  # temperature 0 = consistent answers

    tokenizer = AutoTokenizer.from_pretrained(LOCAL_LLM_NAME)  # text <-> numbers
    model = AutoModelForCausalLM.from_pretrained(  # download/load the weights
        LOCAL_LLM_NAME,
        torch_dtype="auto",  # use the model's saved precision
        device_map="auto",  # GPU if available, else CPU
    )
    generator = pipeline(  # simple wrapper around model + tokenizer
        "text-generation",
        model=model,
        tokenizer=tokenizer,
        max_new_tokens=256,  # max answer length
        do_sample=False,  # deterministic output
        temperature=None,  # silences the unused-temperature warning
        return_full_text=False,  # return only the new answer, not the prompt
    )
    return ChatHuggingFace(llm=HuggingFacePipeline(pipeline=generator))  # applies the model's chat template


def build_rag_chain(pdf_dir):
    """Assemble everything into one chain. Call this ONCE at startup (it is slow)."""
    chunks = load_chunks(pdf_dir)  # step 1: load + chunk
    if not chunks:  # fail early with a clear message
        raise RuntimeError(f"No PDFs found in '{pdf_dir}'. Add at least one PDF.")

    retriever = build_retriever(chunks)  # step 2: index + hybrid retrieval + rerank
    llm = build_llm()  # step 3: choose the LLM

    prompt = ChatPromptTemplate.from_messages([  # step 4: the instructions to the LLM
        ("system",
         "You are an assistant for question-answering tasks. "
         "Use the following pieces of retrieved context to answer the question. "
         "If you do not know the answer, say that you don't know. "
         "Keep the answer concise.\n\nContext:\n{context}"),  # {context} gets the retrieved chunks
        ("human", "{input}"),  # {input} gets the user's question
    ])

    qa_chain = create_stuff_documents_chain(llm, prompt)  # chunks + prompt -> LLM -> answer
    return create_retrieval_chain(retriever, qa_chain)  # question -> retrieve -> qa_chain
