"""
main.py  =  the web layer (FastAPI).
It handles HTTP: routes, validation, security, errors, logging, integrations.
It does NOT contain AI logic; that lives in rag.py.
"""

import os  # read environment variables and file names
import time  # measure request duration
import logging  # write log messages
import secrets  # safe comparison of secrets
from contextlib import asynccontextmanager  # helper for startup/shutdown logic

import httpx  # HTTP client, used to call Slack
from fastapi import FastAPI, Depends, Header, HTTPException, BackgroundTasks  # FastAPI building blocks
from pydantic import BaseModel, Field  # data models + validation rules

from app.rag import build_rag_chain  # the AI layer


# ------------------------------------------------------------------
# 1. CONFIGURATION AND LOGGING
# ------------------------------------------------------------------
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")  # log format: time, level, message
logger = logging.getLogger("rag-api")  # named logger for this app

API_KEY = os.environ.get("API_KEY")  # secret clients must send; None if not set
SLACK_WEBHOOK_URL = os.environ.get("SLACK_WEBHOOK_URL")  # optional Slack address; None disables Slack
PDF_DIR = os.environ.get("PDF_DIR", "pdf_data")  # folder with PDFs, default "pdf_data"

state = {}  # shared dictionary; will hold the loaded RAG chain


# ------------------------------------------------------------------
# 2. STARTUP / SHUTDOWN (lifespan)
# ------------------------------------------------------------------
@asynccontextmanager  # turns the function below into a startup/shutdown manager
async def lifespan(app: FastAPI):
    logger.info("Loading RAG chain (this can take a minute)...")  # tell the operator we are starting
    state["chain"] = build_rag_chain(PDF_DIR)  # build once; every request reuses it
    logger.info("RAG chain ready")  # models are loaded
    yield  # the app now runs and serves requests
    state.clear()  # shutdown: release the chain


app = FastAPI(  # create the application object
    title="PDF RAG API",  # shown in /docs
    version="1.0.0",
    lifespan=lifespan,  # register startup/shutdown logic
)


# ------------------------------------------------------------------
# 3. DATA MODELS (contracts for input and output)
# ------------------------------------------------------------------
class Question(BaseModel):  # INPUT: what the client must send
    question: str = Field(..., min_length=3, max_length=1000)  # required text, 3-1000 characters


class Source(BaseModel):  # one source reference in the output
    file: str  # PDF file name
    page: int | None = None  # page number, or None if unknown


class Answer(BaseModel):  # OUTPUT: what the client receives
    answer: str  # the generated answer
    sources: list[Source]  # the chunks it was based on


# ------------------------------------------------------------------
# 4. SECURITY (dependency)
# ------------------------------------------------------------------
def verify_key(x_api_key: str = Header(...)):  # reads the "x-api-key" header; required
    if not API_KEY or not secrets.compare_digest(x_api_key, API_KEY):  # no server key, or wrong key
        raise HTTPException(status_code=401, detail="Invalid or missing API key")  # stop the request with 401


# ------------------------------------------------------------------
# 5. INTEGRATION (Slack)
# ------------------------------------------------------------------
def post_to_slack(question: str, answer: str):
    if not SLACK_WEBHOOK_URL:  # integration is optional
        return  # do nothing if not configured
    try:
        httpx.post(  # send an HTTP POST to Slack
            SLACK_WEBHOOK_URL,
            json={"text": f"*Q:* {question}\n*A:* {answer}"},  # Slack message; *text* = bold
            timeout=5,  # never wait more than 5 seconds
        )
    except Exception as e:  # Slack down? Do not break the API
        logger.warning("Slack post failed: %s", e)  # just record it


# ------------------------------------------------------------------
# 6. ENDPOINTS
# ------------------------------------------------------------------
@app.get("/health")  # GET /health
def health():
    return {"status": "ok", "model_loaded": "chain" in state}  # used by Docker/hosts to check the app is alive


@app.post("/ask", response_model=Answer, dependencies=[Depends(verify_key)])  # POST /ask, key check runs first
def ask(q: Question, background_tasks: BackgroundTasks):  # q = validated body; background_tasks injected by FastAPI
    start = time.time()  # start timer
    try:
        result = state["chain"].invoke({"input": q.question})  # run the RAG chain
    except Exception:  # anything went wrong inside the AI layer
        logger.exception("RAG failed for question: %s", q.question)  # log full error for developers
        raise HTTPException(status_code=500, detail="Failed to generate an answer")  # clean error for the client

    answer = result["answer"].strip()  # answer text without extra spaces

    sources = []  # will hold Source objects
    for d in result["context"]:  # each retrieved chunk
        page = d.metadata.get("page")  # PyPDF page numbers start at 0
        sources.append(Source(
            file=os.path.basename(d.metadata.get("source", "unknown")),  # file name only, not full path
            page=page + 1 if isinstance(page, int) else None,  # human page number
        ))

    background_tasks.add_task(post_to_slack, q.question, answer)  # runs AFTER the response is sent
    logger.info("Answered in %.2fs", time.time() - start)  # record latency
    return Answer(answer=answer, sources=sources)  # FastAPI validates it and converts it to JSON
