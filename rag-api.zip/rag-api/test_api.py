"""Quick manual test. Start the server first, then run: python test_api.py"""
import httpx  # HTTP client

URL = "http://localhost:8000"  # where the API is running
KEY = "my-secret-key"  # must match the API_KEY you started the server with

print("health:", httpx.get(f"{URL}/health").json())  # 1. is the server alive?

r = httpx.post(f"{URL}/ask", headers={"x-api-key": KEY},
               json={"question": "What is this document about?"}, timeout=120)  # 2. valid request
print("valid:", r.status_code, r.json())  # expect 200

r = httpx.post(f"{URL}/ask", headers={"x-api-key": "wrong"},
               json={"question": "What is this document about?"})  # 3. wrong key
print("wrong key:", r.status_code)  # expect 401

r = httpx.post(f"{URL}/ask", headers={"x-api-key": KEY}, json={"question": "hi"})  # 4. too-short question
print("short question:", r.status_code)  # expect 422
